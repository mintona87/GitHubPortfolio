# new-aiken-stuff


Working on my own version of an uncollateralized NFT Rental contract. 

The code is written in two parts:
1. NFT_Rental_Validator --> _on-chain_
2. NFT_Rental_Lucid --> _off-chain_

**Here is a high-level overview of how the contract works:**
1. The renter pays the rental fee upfront, and the NFT is moved to a sub-address under the renter's control.
2. The NFT remains in the renter's sub-address for the duration of the rental period and cannot be moved by the renter.
3. At the end of the rental period, the owner of the NFT can initiate a transaction to move the NFT back to their own address.
